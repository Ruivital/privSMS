#!/usr/bin/env bash
# =====================================================================
#  PrivSMS - compilação automática para Linux Mint / Ubuntu / Debian
#  Verifica o que falta (JDK 17, ferramentas, Android SDK, Gradle),
#  instala se necessário, compila e deixa o APK na pasta deste script.
#  Uso:  ./build.sh            (APK debug)
#        ./build.sh test       (corre também os testes unitários)
# =====================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

SDK_DIR="${ANDROID_HOME:-$HOME/Android/Sdk}"
CMDLINE_VER="11076708"
CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_VER}_latest.zip"
GRADLE_VER="8.7"
GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VER}-bin.zip"
GRADLE_HOME_DIR="$HOME/.privsms-tools/gradle-${GRADLE_VER}"

ok()   { echo "  ✓ $*"; }
info() { echo "  → $*"; }
fail() { echo "  ✗ $*" >&2; exit 1; }

echo "=== Compilação PrivSMS ==="
echo "A verificar dependências..."

# ---------- 1. Pacotes do sistema ----------
APT_NEEDED=()
command -v curl  >/dev/null 2>&1 || APT_NEEDED+=(curl)
command -v unzip >/dev/null 2>&1 || APT_NEEDED+=(unzip)

java_major() {
  command -v java >/dev/null 2>&1 || { echo 0; return; }
  java -version 2>&1 | awk -F\" '/version/ {split($2,a,"."); print (a[1]=="1"?a[2]:a[1]); exit}'
}
JV="$(java_major)"
if [ "$JV" -lt 17 ] || ! command -v javac >/dev/null 2>&1; then
  APT_NEEDED+=(openjdk-17-jdk)
fi

if [ ${#APT_NEEDED[@]} -gt 0 ]; then
  info "A instalar: ${APT_NEEDED[*]} (pede a palavra-passe sudo)"
  sudo apt-get update -y
  sudo apt-get install -y "${APT_NEEDED[@]}"
fi
JV="$(java_major)"
{ [ "$JV" -ge 17 ] && command -v javac >/dev/null 2>&1; } || fail "JDK 17+ não disponível."
ok "JDK $JV"

# Se existirem várias versões, prefere a 17 para o Gradle/AGP.
if [ "$JV" -gt 21 ] && [ -d /usr/lib/jvm/java-17-openjdk-amd64 ]; then
  export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
  export PATH="$JAVA_HOME/bin:$PATH"
  ok "A usar JAVA_HOME=$JAVA_HOME"
fi

# ---------- 2. Android SDK ----------
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
SDKMANAGER="$SDK_DIR/cmdline-tools/latest/bin/sdkmanager"

if [ ! -x "$SDKMANAGER" ]; then
  info "Android SDK não encontrado em $SDK_DIR. A descarregar command-line tools..."
  mkdir -p "$SDK_DIR/cmdline-tools"
  TMP="$(mktemp -d)"
  curl -fL --retry 3 -o "$TMP/cmdline.zip" "$CMDLINE_URL"
  unzip -q "$TMP/cmdline.zip" -d "$TMP"
  rm -rf "$SDK_DIR/cmdline-tools/latest"
  mv "$TMP/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
  rm -rf "$TMP"
fi
ok "Android command-line tools"

NEED_PKGS=()
[ -d "$SDK_DIR/platform-tools" ]            || NEED_PKGS+=("platform-tools")
[ -d "$SDK_DIR/platforms/android-34" ]      || NEED_PKGS+=("platforms;android-34")
[ -d "$SDK_DIR/build-tools/34.0.0" ]        || NEED_PKGS+=("build-tools;34.0.0")
if [ ${#NEED_PKGS[@]} -gt 0 ]; then
  info "A instalar pacotes SDK: ${NEED_PKGS[*]}"
  yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
  "$SDKMANAGER" "${NEED_PKGS[@]}"
fi
yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
ok "Android SDK (platform 34, build-tools 34.0.0)"

echo "sdk.dir=$SDK_DIR" > "$DIR/local.properties"

# ---------- 3. Gradle ----------
if [ -x "$DIR/gradlew" ] && [ -f "$DIR/gradle/wrapper/gradle-wrapper.jar" ]; then
  GRADLE_CMD=("$DIR/gradlew")
  ok "Gradle wrapper do projeto"
else
  if [ ! -x "$GRADLE_HOME_DIR/bin/gradle" ]; then
    info "A descarregar Gradle $GRADLE_VER..."
    mkdir -p "$HOME/.privsms-tools"
    TMP="$(mktemp -d)"
    curl -fL --retry 3 -o "$TMP/gradle.zip" "$GRADLE_URL"
    unzip -q "$TMP/gradle.zip" -d "$HOME/.privsms-tools"
    rm -rf "$TMP"
  fi
  info "A gerar o Gradle wrapper..."
  "$GRADLE_HOME_DIR/bin/gradle" -p "$DIR" wrapper --gradle-version "$GRADLE_VER" --no-daemon -q
  chmod +x "$DIR/gradlew"
  GRADLE_CMD=("$DIR/gradlew")
  ok "Gradle $GRADLE_VER"
fi

# ---------- 4. Compilar ----------
echo "A compilar (a primeira vez demora vários minutos: descarrega dependências)..."
"${GRADLE_CMD[@]}" clean
if [ "${1:-}" = "test" ]; then
  "${GRADLE_CMD[@]}" testDebugUnitTest
fi
"${GRADLE_CMD[@]}" assembleDebug

APK="$DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  cp "$APK" "$DIR/PrivSMS-debug.apk"
  echo
  echo "✓ APK gerado com sucesso!"
  echo "Localização: $DIR/PrivSMS-debug.apk"
  echo "Para instalar: adb install -r \"$DIR/PrivSMS-debug.apk\""
else
  fail "Erro na compilação: APK não encontrado."
fi
