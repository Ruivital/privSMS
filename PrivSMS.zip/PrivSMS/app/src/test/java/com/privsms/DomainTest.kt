package com.privsms

import com.privsms.domain.model.Expiry
import com.privsms.util.fromB64
import com.privsms.util.toB64
import com.privsms.util.toCountdown
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DomainTest {
    @Test fun expiryIsViewedPlusTtl() {
        assertEquals(1_000L + 60_000L, Expiry.compute(1_000L, 60))
    }

    @Test fun noTtlMeansNoExpiry() {
        assertNull(Expiry.compute(1_000L, 0))
    }

    @Test fun base64UrlRoundTrip() {
        val b = ByteArray(32) { it.toByte() }
        assertArrayEquals(b, b.toB64().fromB64())
    }

    @Test fun countdownFormat() {
        assertEquals("1:05", 65_000L.toCountdown())
        assertEquals("1:00:00", 3_600_000L.toCountdown())
        assertEquals("0:00", (-5L).toCountdown())
    }
}
