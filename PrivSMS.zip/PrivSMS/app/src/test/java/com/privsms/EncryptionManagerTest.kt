package com.privsms

import com.privsms.crypto.EncryptionManager
import com.privsms.crypto.KeyProvider
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.GeneralSecurityException
import java.security.SecureRandom

private class FakeKeys : KeyProvider {
    private val priv = X25519PrivateKeyParameters(SecureRandom())
    override val privateKey: ByteArray = priv.encoded
    override val publicKey: ByteArray = priv.generatePublicKey().encoded
}

class EncryptionManagerTest {
    private val alice = FakeKeys()
    private val bob = FakeKeys()
    private val a = EncryptionManager(alice)
    private val b = EncryptionManager(bob)

    @Test fun bothSidesDeriveTheSameKey() {
        assertArrayEquals(a.sessionKey(bob.publicKey), b.sessionKey(alice.publicKey))
    }

    @Test fun roundTrip() {
        val msg = "olá, mundo 🔒".toByteArray()
        val enc = a.encrypt(bob.publicKey, msg)
        assertArrayEquals(msg, b.decrypt(alice.publicKey, enc))
    }

    @Test fun ciphertextIsDifferentEachTimeAndNotPlaintext() {
        val msg = "segredo".toByteArray()
        val e1 = a.encrypt(bob.publicKey, msg)
        val e2 = a.encrypt(bob.publicKey, msg)
        assertFalse(e1.contentEquals(e2))
        assertFalse(String(e1).contains("segredo"))
    }

    @Test fun tamperedDataIsRejected() {
        val enc = a.encrypt(bob.publicKey, "x".toByteArray())
        enc[enc.size - 1] = (enc[enc.size - 1].toInt() xor 1).toByte()
        val failed = try { b.decrypt(alice.publicKey, enc); false } catch (e: GeneralSecurityException) { true }
        assertTrue(failed)
    }

    @Test fun thirdPartyCannotDecrypt() {
        val eve = EncryptionManager(FakeKeys())
        val enc = a.encrypt(bob.publicKey, "x".toByteArray())
        val failed = try { eve.decrypt(alice.publicKey, enc); false } catch (e: GeneralSecurityException) { true }
        assertTrue(failed)
    }
}
