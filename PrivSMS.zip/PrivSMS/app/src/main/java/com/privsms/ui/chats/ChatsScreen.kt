package com.privsms.ui.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.privsms.domain.model.Conversation
import com.privsms.domain.model.MsgType
import com.privsms.util.toClock

/** Ecrã principal: lista de conversas. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(vm: ChatsViewModel, onOpen: (String) -> Unit, onContacts: () -> Unit, onSettings: () -> Unit) {
    val list by vm.conversations.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PrivSMS", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                actions = { IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Definições") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onContacts) { Icon(Icons.Filled.Add, "Contactos") }
        }
    ) { pad ->
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Sem conversas.\nToque em + para adicionar um contacto trocando QR Codes.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else LazyColumn(Modifier.padding(pad)) {
            items(list, key = { it.contactKey }) { ConversationRow(it) { onOpen(it.contactKey) } }
        }
    }
}

@Composable
private fun ConversationRow(c: Conversation, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(c.name)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
            val preview = when (c.lastType) {
                null -> "Sem mensagens"
                MsgType.IMAGE -> "📷 Fotografia"
                MsgType.VIDEO -> "🎬 Vídeo"
                MsgType.FILE -> "📎 Documento"
                else -> c.lastBody.orEmpty()
            }
            Text(preview, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(horizontalAlignment = Alignment.End) {
            c.lastTime?.let { Text(it.toClock(), style = MaterialTheme.typography.labelSmall) }
            if (c.unread > 0) {
                Spacer(Modifier.height(4.dp))
                Box(Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 7.dp, vertical = 2.dp)) {
                    Text("${c.unread}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

/** Avatar simples com a inicial do nome. */
@Composable
fun Avatar(name: String, size: Int = 46) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) { Text(name.firstOrNull()?.uppercase() ?: "?", color = Color.White, fontWeight = FontWeight.Bold) }
}
