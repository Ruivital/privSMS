package com.privsms.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.privsms.MainActivity

/** Notificações de novas mensagens (com opção de esconder o conteúdo). */
class Notifier(private val ctx: Context) {
    init {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MSG, "Mensagens", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Ligação P2P", NotificationManager.IMPORTANCE_MIN))
    }

    fun message(contactKey: String, name: String, text: String, hidePreview: Boolean) {
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_chat", contactKey)
        }
        val pi = PendingIntent.getActivity(ctx, contactKey.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH_MSG)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(if (hidePreview) "PrivSMS" else name)
            .setContentText(if (hidePreview) "Nova mensagem" else text)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true).setContentIntent(pi).build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(contactKey.hashCode(), n) }
    }

    fun serviceNotification() = NotificationCompat.Builder(ctx, CH_SERVICE)
        .setSmallIcon(android.R.drawable.sym_action_chat)
        .setContentTitle("PrivSMS ativo")
        .setContentText("A aguardar pedidos de ligação dos seus contactos")
        .setOngoing(true).build()

    companion object { const val CH_MSG = "messages"; const val CH_SERVICE = "service" }
}
