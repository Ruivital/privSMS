package com.privsms.domain.usecase

import android.net.Uri
import com.privsms.data.repository.MessageRepository

/** Envia uma mensagem de texto (fica em fila até o destinatário estar online). */
class SendMessageUseCase(private val repo: MessageRepository) {
    suspend operator fun invoke(contactKey: String, text: String, ttlSeconds: Long, replyTo: String?) {
        if (text.isBlank()) return
        repo.sendText(contactKey, text.trim(), ttlSeconds, replyTo)
    }
}

/** Envia um ficheiro (imagem, vídeo ou documento). */
class SendMediaUseCase(private val repo: MessageRepository) {
    suspend operator fun invoke(contactKey: String, uri: Uri, ttlSeconds: Long, replyTo: String?) =
        repo.sendMedia(contactKey, uri, ttlSeconds, replyTo)
}

/** Apaga (com overwrite) as mensagens temporárias expiradas. */
class DeleteExpiredMessagesUseCase(private val repo: MessageRepository) {
    suspend operator fun invoke(): Int = repo.purgeExpired()
}

/** Marca as mensagens recebidas como vistas e inicia os temporizadores. */
class MarkConversationSeenUseCase(private val repo: MessageRepository) {
    suspend operator fun invoke(contactKey: String) = repo.markSeen(contactKey)
}
