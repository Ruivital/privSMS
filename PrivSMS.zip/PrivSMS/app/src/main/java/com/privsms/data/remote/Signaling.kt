package com.privsms.data.remote

import com.privsms.util.sha256
import com.privsms.util.toHex
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * Canal de sinalização: transporta apenas texto opaco (já cifrado E2E).
 * As mensagens do chat NUNCA passam por aqui, só pedidos de ligação / SDP / ICE.
 */
interface SignalingChannel {
    val incoming: SharedFlow<String>
    suspend fun send(targetPublicKey: ByteArray, payload: String)
    fun start(scope: CoroutineScope, myPublicKey: ByteArray)
    fun stop()
}

/** Tópico de entrada de um utilizador no relay público (derivado da chave pública). */
fun inboxTopic(publicKey: ByteArray): String = "privsms-" + publicKey.sha256().toHex().take(40)

/**
 * Relay de sinalização tipo "caixa de correio" (ntfy). Sem cache no servidor ("Cache: no"),
 * por isso nada fica guardado: se o destinatário estiver offline, o pedido perde-se
 * (é exatamente o "verificar se está online" que queremos).
 * O URL pode ser um servidor próprio (configurável nas definições).
 */
class NtfySignaling(private val baseUrl: () -> String) : SignalingChannel {

    private val _incoming = MutableSharedFlow<String>(extraBufferCapacity = 64)
    override val incoming: SharedFlow<String> = _incoming

    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(30, TimeUnit.SECONDS).build()
    private val postClient = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()
    private var job: Job? = null
    @Volatile private var call: okhttp3.Call? = null

    override fun start(scope: CoroutineScope, myPublicKey: ByteArray) {
        stop()
        val topic = inboxTopic(myPublicKey)
        job = scope.launch(Dispatchers.IO) {
            var backoff = 2_000L
            while (isActive) {
                try {
                    val req = Request.Builder().url("${baseUrl().trimEnd('/')}/$topic/json").build()
                    val c = http.newCall(req); call = c
                    c.execute().use { resp ->
                        if (!resp.isSuccessful) error("HTTP ${resp.code}")
                        backoff = 2_000L
                        val src = resp.body!!.source()
                        while (isActive && !src.exhausted()) {
                            val line = src.readUtf8Line() ?: break
                            val j = runCatching { JSONObject(line) }.getOrNull() ?: continue
                            if (j.optString("event") == "message") _incoming.tryEmit(j.optString("message"))
                        }
                    }
                } catch (_: Exception) { /* sem rede / cancelado: tenta de novo */ }
                if (isActive) { delay(backoff); backoff = (backoff * 2).coerceAtMost(60_000L) }
            }
        }
    }

    override suspend fun send(targetPublicKey: ByteArray, payload: String) {
        val req = Request.Builder()
            .url("${baseUrl().trimEnd('/')}/${inboxTopic(targetPublicKey)}")
            .header("Cache", "no").header("Firebase", "no")
            .post(payload.toRequestBody("text/plain".toMediaType())).build()
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            postClient.newCall(req).execute().close()
        }
    }

    override fun stop() { job?.cancel(); call?.cancel(); job = null }
}

/** Sinalização por socket TCP dentro de um grupo Wi-Fi Direct (sem internet, sem servidor). */
class TcpSignaling : SignalingChannel {
    private val _incoming = MutableSharedFlow<String>(extraBufferCapacity = 64)
    override val incoming: SharedFlow<String> = _incoming
    @Volatile private var out: PrintWriter? = null
    private var scope: CoroutineScope? = null
    private var server: ServerSocket? = null
    private var socket: Socket? = null

    val isConnected: Boolean get() = out != null

    override fun start(scope: CoroutineScope, myPublicKey: ByteArray) { this.scope = scope }

    /** Dono do grupo: aguarda ligação do outro dispositivo. */
    fun listen(port: Int) {
        scope?.launch(Dispatchers.IO) {
            runCatching {
                server?.close()
                server = ServerSocket(port).also { attach(it.accept()) }
            }
        }
    }

    /** Cliente: liga-se ao dono do grupo (com algumas tentativas). */
    fun connect(host: String, port: Int) {
        scope?.launch(Dispatchers.IO) {
            repeat(10) {
                if (out != null) return@launch
                runCatching {
                    val s = Socket(); s.connect(InetSocketAddress(host, port), 3_000); attach(s)
                }
                delay(1_000)
            }
        }
    }

    private fun attach(s: Socket) {
        socket = s
        out = PrintWriter(s.getOutputStream(), true)
        scope?.launch(Dispatchers.IO) {
            runCatching {
                s.getInputStream().bufferedReader().forEachLine { _incoming.tryEmit(it) }
            }
            out = null
        }
    }

    /** O payload é uma única linha (Base64/JSON sem \n). */
    override suspend fun send(targetPublicKey: ByteArray, payload: String) {
        out?.println(payload)
    }

    override fun stop() {
        runCatching { socket?.close(); server?.close() }; out = null
    }
}

/** Agrega vários canais: envia por todos os que estiverem ativos e junta as respostas. */
class MultiSignaling(
    private val ntfy: NtfySignaling,
    private val tcp: TcpSignaling
) : SignalingChannel {
    private val _incoming = MutableSharedFlow<String>(extraBufferCapacity = 128)
    override val incoming: SharedFlow<String> = _incoming

    override fun start(scope: CoroutineScope, myPublicKey: ByteArray) {
        ntfy.start(scope, myPublicKey); tcp.start(scope, myPublicKey)
        scope.launch { ntfy.incoming.collect { _incoming.emit(it) } }
        scope.launch { tcp.incoming.collect { _incoming.emit(it) } }
    }

    override suspend fun send(targetPublicKey: ByteArray, payload: String) {
        if (tcp.isConnected) runCatching { tcp.send(targetPublicKey, payload) }
        runCatching { ntfy.send(targetPublicKey, payload) }
    }

    override fun stop() { ntfy.stop(); tcp.stop() }
}
