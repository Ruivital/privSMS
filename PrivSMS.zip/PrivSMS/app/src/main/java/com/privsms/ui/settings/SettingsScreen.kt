package com.privsms.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.privsms.data.repository.SettingsStore
import com.privsms.util.Constants
import com.privsms.util.fingerprint
import com.privsms.util.toB64

/** Definições: perfil, segurança e sinalização. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(settings: SettingsStore, myPublicKey: ByteArray, onBack: () -> Unit) {
    val name by settings.name.collectAsState()
    val lock by settings.lockEnabled.collectAsState()
    val hide by settings.hidePreview.collectAsState()
    val secure by settings.secureScreen.collectAsState()
    val ttl by settings.defaultTtl.collectAsState()
    val url by settings.signalingUrl.collectAsState()
    var nameField by remember { mutableStateOf(name) }
    var urlField by remember { mutableStateOf(url) }
    var ttlMenu by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Definições") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
        })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(nameField, { nameField = it; settings.setName(it.take(40)) },
                label = { Text("O meu nome (aparece no QR Code)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("Impressão digital da minha chave", fontWeight = FontWeight.Bold)
            Text(myPublicKey.toB64().fingerprint(), style = MaterialTheme.typography.bodyMedium)

            SwitchRow("Bloquear app (biometria / PIN do telemóvel)", lock) { settings.setLock(it) }
            SwitchRow("Esconder conteúdo nas notificações", hide) { settings.setHidePreview(it) }
            SwitchRow("Impedir capturas de ecrã", secure) { settings.setSecureScreen(it) }

            Text("Temporizador por defeito das novas mensagens", fontWeight = FontWeight.Bold)
            Box {
                OutlinedButton(onClick = { ttlMenu = true }) {
                    Text(Constants.TTL_OPTIONS.firstOrNull { it.second == ttl }?.first ?: "Desligado")
                }
                DropdownMenu(ttlMenu, { ttlMenu = false }) {
                    Constants.TTL_OPTIONS.forEach { (label, s) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { settings.setDefaultTtl(s); ttlMenu = false })
                    }
                }
            }

            Text("Servidor de sinalização", fontWeight = FontWeight.Bold)
            Text(
                "Usado só para pedidos de ligação cifrados (nunca mensagens nem ficheiros) e sem guardar nada. " +
                    "Pode apontar para um servidor ntfy próprio.",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedTextField(urlField, { urlField = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("URL (reinicie a app após alterar)") })
            Button(onClick = { settings.setSignalingUrl(urlField) }) { Text("Guardar URL") }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}
