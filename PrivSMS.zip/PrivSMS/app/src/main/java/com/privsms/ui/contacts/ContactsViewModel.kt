package com.privsms.ui.contacts

import android.net.wifi.p2p.WifiP2pDevice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.privsms.AppContainer
import com.privsms.domain.model.Contact
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Contactos, QR Code e descoberta Wi-Fi Direct. */
class ContactsViewModel(private val c: AppContainer) : ViewModel() {
    val contacts: StateFlow<List<Contact>> =
        c.contacts.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val states = c.p2p.states
    val peers: StateFlow<List<WifiP2pDevice>> = c.wifiDirect.peers
    val wifiStatus = c.wifiDirect.status
    var message by mutableStateOf<String?>(null)

    fun myInvite(): String = c.contacts.myInvite(c.settings.name.value)

    fun addFromQr(text: String, onAdded: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { c.contacts.addFromInvite(text) }
                .onSuccess { message = "${it.name} adicionado."; onAdded(it.publicKey) }
                .onFailure { message = it.message }
        }
    }

    fun startWifiDirect() = c.wifiDirect.start()
    fun connectPeer(d: WifiP2pDevice) = c.wifiDirect.connect(d)
    fun stopWifiDirect() = c.wifiDirect.stop()
    fun block(key: String, b: Boolean) { viewModelScope.launch { c.contacts.setBlocked(key, b) } }
    fun delete(key: String) { viewModelScope.launch { c.contacts.delete(key); c.messages.clearChat(key) } }
}
