package com.privsms.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE publicKey = :key")
    suspend fun get(key: String): ContactEntity?

    @Query("SELECT * FROM contacts WHERE publicKey = :key")
    fun observe(key: String): Flow<ContactEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: ContactEntity)

    @Query("UPDATE contacts SET blocked = :blocked WHERE publicKey = :key")
    suspend fun setBlocked(key: String, blocked: Boolean)

    @Query("DELETE FROM contacts WHERE publicKey = :key")
    suspend fun delete(key: String)

    @Query("SELECT publicKey FROM contacts WHERE blocked = 0")
    suspend fun activeKeys(): List<String>
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE contactKey = :k ORDER BY createdAt ASC")
    fun observe(k: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun get(id: String): MessageEntity?

    /** Só sobe o estado (nunca desce). */
    @Query("UPDATE messages SET status = :s WHERE id = :id AND status < :s")
    suspend fun raiseStatus(id: String, s: Int)

    @Query("SELECT * FROM messages WHERE contactKey = :k AND outgoing = 1 AND status < 2 ORDER BY createdAt")
    suspend fun undelivered(k: String): List<MessageEntity>

    @Query("SELECT DISTINCT contactKey FROM messages WHERE outgoing = 1 AND status < 2")
    suspend fun contactsWithUndelivered(): List<String>

    @Query("SELECT * FROM messages WHERE contactKey = :k AND outgoing = 0 AND viewedAt IS NULL")
    suspend fun unseenIncoming(k: String): List<MessageEntity>

    @Query(
        "UPDATE messages SET viewedAt = :t, " +
            "expiresAt = CASE WHEN ttlSeconds > 0 THEN :t + ttlSeconds * 1000 ELSE NULL END " +
            "WHERE id = :id AND viewedAt IS NULL"
    )
    suspend fun markViewed(id: String, t: Long)

    @Query("UPDATE messages SET reaction = :r WHERE id = :id")
    suspend fun setReaction(id: String, r: String?)

    @Query("SELECT * FROM messages WHERE expiresAt IS NOT NULL AND expiresAt <= :now")
    suspend fun expired(now: Long): List<MessageEntity>

    @Query("SELECT MIN(expiresAt) FROM messages WHERE expiresAt IS NOT NULL")
    suspend fun nextExpiry(): Long?

    @Query("DELETE FROM messages WHERE id IN (:ids)")
    suspend fun delete(ids: List<String>)

    @Query("SELECT id FROM messages WHERE contactKey = :k AND outgoing = 0 AND viewedAt IS NOT NULL ORDER BY createdAt DESC LIMIT 200")
    suspend fun viewedIncomingIds(k: String): List<String>

    @Query("SELECT * FROM messages WHERE contactKey = :k")
    suspend fun allFor(k: String): List<MessageEntity>

    @Query("DELETE FROM messages WHERE contactKey = :k")
    suspend fun clear(k: String)

    @Query(
        "SELECT c.publicKey AS contactKey, c.name AS name, " +
            "(SELECT body FROM messages m WHERE m.contactKey = c.publicKey ORDER BY createdAt DESC LIMIT 1) AS lastBody, " +
            "(SELECT type FROM messages m WHERE m.contactKey = c.publicKey ORDER BY createdAt DESC LIMIT 1) AS lastType, " +
            "(SELECT createdAt FROM messages m WHERE m.contactKey = c.publicKey ORDER BY createdAt DESC LIMIT 1) AS lastTime, " +
            "(SELECT COUNT(*) FROM messages m WHERE m.contactKey = c.publicKey AND m.outgoing = 0 AND m.viewedAt IS NULL) AS unread " +
            "FROM contacts c WHERE c.blocked = 0 ORDER BY lastTime DESC"
    )
    fun conversations(): Flow<List<ConversationRow>>
}
