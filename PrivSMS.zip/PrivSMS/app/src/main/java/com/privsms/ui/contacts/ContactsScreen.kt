package com.privsms.ui.contacts

import android.Manifest
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.privsms.domain.model.ConnState
import com.privsms.ui.chats.Avatar

private fun qrBitmap(text: String, size: Int = 640): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m[x, y]) AColor.BLACK else AColor.WHITE)
    return bmp
}

/** Contactos: o meu QR, ler QR, Wi-Fi Direct e lista de contactos. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(vm: ContactsViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val contacts by vm.contacts.collectAsState()
    val states by vm.states.collectAsState()
    val peers by vm.peers.collectAsState()
    val wifiStatus by vm.wifiStatus.collectAsState()
    val snack = remember { SnackbarHostState() }
    val qr = remember { qrBitmap(vm.myInvite()) }

    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    DisposableEffect(Unit) { onDispose { vm.stopWifiDirect() } }

    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.let { vm.addFromQr(it) { key -> onOpen(key) } }
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) vm.startWifiDirect() else vm.message = "Permissão necessária para o Wi-Fi Direct."
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(title = { Text("Contactos") }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
            })
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("O meu QR Code", fontWeight = FontWeight.Bold)
                        Text("Mostre ao seu contacto para trocarem chaves públicas.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        Image(qr.asImageBitmap(), "QR Code", Modifier.size(220.dp))
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                .setPrompt("Aponte ao QR Code do contacto").setBeepEnabled(false).setOrientationLocked(false))
                        }) { Icon(Icons.Filled.QrCodeScanner, null); Spacer(Modifier.width(8.dp)); Text("Ler QR Code") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Dispositivos próximos (Wi-Fi Direct)", fontWeight = FontWeight.Bold)
                        if (wifiStatus.isNotEmpty()) Text(wifiStatus, style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onClick = {
                            val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
                            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                            perms.launch(p)
                        }) { Text("Procurar") }
                        peers.forEach { d ->
                            TextButton(onClick = { vm.connectPeer(d) }) { Text(d.deviceName.ifBlank { d.deviceAddress }) }
                        }
                    }
                }
            }
            item { Text("Os meus contactos", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            if (contacts.isEmpty()) item { Text("Ainda não tem contactos.", style = MaterialTheme.typography.bodyMedium) }
            items(contacts, key = { it.publicKey }) { c ->
                var menu by remember { mutableStateOf(false) }
                val st = states[c.publicKey] ?: ConnState.DISCONNECTED
                Row(Modifier.fillMaxWidth().clickable { onOpen(c.publicKey) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 40)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name + if (c.blocked) " (bloqueado)" else "")
                        Text(if (st == ConnState.CONNECTED) "ligado" else "offline", style = MaterialTheme.typography.labelSmall)
                    }
                    Box {
                        TextButton(onClick = { menu = true }) { Text("⋮") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(if (c.blocked) "Desbloquear" else "Bloquear") },
                                onClick = { menu = false; vm.block(c.publicKey, !c.blocked) })
                            DropdownMenuItem(text = { Text("Apagar contacto") }, onClick = { menu = false; vm.delete(c.publicKey) })
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
