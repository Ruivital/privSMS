package com.privsms.data.remote

import android.content.Context
import com.privsms.crypto.EncryptionManager
import com.privsms.crypto.KeyManager
import com.privsms.domain.model.ConnState
import com.privsms.util.Constants
import com.privsms.util.fromB64
import com.privsms.util.fromB64Std
import com.privsms.util.toB64
import com.privsms.util.toB64Std
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.webrtc.PeerConnectionFactory
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

/**
 * Orquestra as ligações P2P:
 *  1. "Pedido de ligação": envia PING cifrado ao contacto pelo canal de sinalização;
 *  2. se o contacto estiver online responde PONG -> só então é negociada a ligação WebRTC;
 *  3. com o DataChannel aberto, as mensagens seguem diretamente de dispositivo a dispositivo.
 */
class WebRTCManager(
    context: Context,
    private val keys: KeyManager,
    private val crypto: EncryptionManager,
    private val signaling: SignalingChannel,
    private val scope: CoroutineScope,
    private val isKnownContact: suspend (String) -> Boolean
) {
    private val factory: PeerConnectionFactory
    private val conns = ConcurrentHashMap<String, P2PConnection>()
    private val pongWaiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private val locks = ConcurrentHashMap<String, Mutex>()
    private val seenNonces = object : LinkedHashMap<String, Boolean>() {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Boolean>?) = size > 512
    }
    private val random = SecureRandom()

    private val _states = MutableStateFlow<Map<String, ConnState>>(emptyMap())
    /** Estado de ligação por contacto (chave pública Base64). */
    val states = _states.asStateFlow()

    private val _frames = MutableSharedFlow<Pair<String, ByteArray>>(extraBufferCapacity = 256)
    /** Frames já decifrados: (chave do contacto, plaintext). */
    val frames: SharedFlow<Pair<String, ByteArray>> = _frames

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    fun start() {
        signaling.start(scope, keys.publicKey)
        scope.launch { signaling.incoming.collect { runCatching { onSignalEnvelope(it) } } }
    }

    fun stop() { conns.values.forEach { it.close() }; signaling.stop() }

    fun stateOf(peer: String): ConnState = _states.value[peer] ?: ConnState.DISCONNECTED
    fun isConnected(peer: String) = stateOf(peer) == ConnState.CONNECTED

    private fun setState(peer: String, s: ConnState) = _states.update { it + (peer to s) }

    private fun connFor(peer: String): P2PConnection = conns.getOrPut(peer) {
        P2PConnection(
            factory, scope,
            sendSignal = { type, data -> sendSignal(peer, type, data) },
            onFrame = { enc -> handleFrame(peer, enc) },
            onStateChanged = { setState(peer, it) }
        )
    }

    private fun handleFrame(peer: String, enc: ByteArray) {
        val plain = runCatching { crypto.decrypt(peer.fromB64(), enc) }.getOrNull() ?: return
        _frames.tryEmit(peer to plain)
    }

    /**
     * Pede ligação ao contacto: verifica se está online (PING/PONG) e só depois negoceia.
     * Devolve true se ficou ligado.
     */
    suspend fun requestConnection(peer: String): Boolean {
        val lock = locks.getOrPut(peer) { Mutex() }
        if (!lock.tryLock()) return isConnected(peer)
        try {
            if (isConnected(peer)) return true
            setState(peer, ConnState.REQUESTING)
            val waiter = CompletableDeferred<Unit>().also { pongWaiters[peer] = it }
            runCatching { sendSignal(peer, SignalType.PING, "") }
            val online = withTimeoutOrNull(Constants.PING_TIMEOUT_MS) { waiter.await(); true } ?: false
            pongWaiters.remove(peer)
            if (!online) { setState(peer, ConnState.DISCONNECTED); return false }
            connFor(peer).start(asInitiator = true)
            // Aguarda até 25 s pelo canal abrir.
            withTimeoutOrNull(25_000) {
                while (!isConnected(peer)) kotlinx.coroutines.delay(200)
            }
            if (!isConnected(peer)) { conns[peer]?.close(); return false }
            return true
        } finally { lock.unlock() }
    }

    /** Cifra e envia um frame pelo DataChannel. */
    suspend fun send(peer: String, plain: ByteArray): Boolean {
        val c = conns[peer] ?: return false
        if (!isConnected(peer)) return false
        return c.send(crypto.encrypt(peer.fromB64(), plain))
    }

    fun disconnect(peer: String) { conns[peer]?.close() }

    // ----------------------- sinalização -----------------------

    private suspend fun sendSignal(peer: String, type: SignalType, data: String) {
        val inner = JSONObject()
            .put("t", type.name).put("d", data)
            .put("ts", System.currentTimeMillis())
            .put("n", ByteArray(12).also { random.nextBytes(it) }.toB64())
            .toString().toByteArray()
        val enc = crypto.encrypt(peer.fromB64(), inner)
        // Envelope numa só linha: remetente (chave pública) + payload cifrado.
        val env = JSONObject().put("s", keys.publicKey.toB64()).put("p", enc.toB64Std()).toString()
        signaling.send(peer.fromB64(), env)
    }

    private suspend fun onSignalEnvelope(raw: String) {
        val env = JSONObject(raw)
        val sender = env.getString("s")
        if (sender == keys.publicKey.toB64()) return
        if (!isKnownContact(sender)) return // só aceita contactos conhecidos e não bloqueados
        val inner = JSONObject(String(crypto.decrypt(sender.fromB64(), env.getString("p").fromB64Std())))
        if (System.currentTimeMillis() - inner.getLong("ts") > Constants.SIGNAL_MAX_AGE_MS) return
        val nonce = inner.getString("n")
        synchronized(seenNonces) { if (seenNonces.put(nonce, true) != null) return }
        val type = SignalType.valueOf(inner.getString("t"))
        val data = inner.optString("d")
        when (type) {
            SignalType.PING -> sendSignal(sender, SignalType.PONG, "")
            SignalType.PONG -> pongWaiters[sender]?.complete(Unit)
            SignalType.OFFER -> {
                val c = connFor(sender)
                // Colisão (ambos iniciaram): a chave pública menor mantém-se como iniciador.
                if (c.state == ConnState.CONNECTING && c.isInitiator && keys.publicKey.toB64() < sender) return
                setState(sender, ConnState.CONNECTING)
                c.onSignal(type, data)
            }
            else -> conns[sender]?.onSignal(type, data)
        }
    }
}
