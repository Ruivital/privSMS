package com.privsms.crypto

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.privsms.util.fromB64Std
import com.privsms.util.toB64Std
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import java.security.SecureRandom

/** Fornece o par de chaves de identidade (abstração para facilitar testes). */
interface KeyProvider {
    val privateKey: ByteArray
    val publicKey: ByteArray
}

/**
 * Gere a identidade do utilizador (Curve25519) e a passphrase da base de dados.
 * Tudo é guardado em EncryptedSharedPreferences, protegido pelo Android Keystore.
 */
class KeyManager(context: Context) : KeyProvider {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "privsms_keys",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    init {
        if (!prefs.contains(K_PRIV)) {
            val priv = X25519PrivateKeyParameters(SecureRandom())
            prefs.edit()
                .putString(K_PRIV, priv.encoded.toB64Std())
                .putString(K_PUB, priv.generatePublicKey().encoded.toB64Std())
                .apply()
        }
        if (!prefs.contains(K_DB)) {
            val pass = ByteArray(32).also { SecureRandom().nextBytes(it) }
            prefs.edit().putString(K_DB, pass.toB64Std()).apply()
        }
    }

    override val privateKey: ByteArray get() = prefs.getString(K_PRIV, null)!!.fromB64Std()
    override val publicKey: ByteArray get() = prefs.getString(K_PUB, null)!!.fromB64Std()

    /** Passphrase aleatória de 256 bits usada pelo SQLCipher. */
    fun databasePassphrase(): ByteArray = prefs.getString(K_DB, null)!!.fromB64Std()

    private companion object {
        const val K_PRIV = "x25519_priv"
        const val K_PUB = "x25519_pub"
        const val K_DB = "db_pass"
    }
}
