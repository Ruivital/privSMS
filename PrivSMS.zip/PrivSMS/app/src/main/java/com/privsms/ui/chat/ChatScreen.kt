package com.privsms.ui.chat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.privsms.domain.model.ConnState
import com.privsms.domain.model.Message
import com.privsms.domain.model.MsgStatus
import com.privsms.domain.model.MsgType
import com.privsms.ui.chats.Avatar
import com.privsms.ui.theme.LocalChatColors
import com.privsms.ui.theme.SeenBlue
import com.privsms.util.Constants
import com.privsms.util.formatRich
import com.privsms.util.toClock
import com.privsms.util.toCountdown
import kotlinx.coroutines.delay
import java.io.File

private fun openFile(ctx: Context, m: Message, share: Boolean = false) {
    val f = File(m.mediaPath ?: return)
    if (!f.exists()) return
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val ext = MimeTypeMap.getFileExtensionFromUrl(m.mediaName ?: "").lowercase()
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        ?: when (m.type) { MsgType.IMAGE -> "image/*"; MsgType.VIDEO -> "video/*"; else -> "*/*" }
    val intent = if (share) Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
    else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(intent, null)) }
}

/** Ecrã de conversa. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val contact by vm.contact.collectAsState()
    val messages by vm.messages.collectAsState()
    val conn by vm.connection.collectAsState()
    val progress by vm.progress.collectAsState()
    val snack = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var showEmoji by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var ttlMenu by remember { mutableStateOf(false) }
    var video by remember { mutableStateOf<Message?>(null) }
    var camUri by remember { mutableStateOf<android.net.Uri?>(null) }

    // Relógio para contadores das mensagens temporárias.
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    LaunchedEffect(vm.error) { vm.error?.let { snack.showSnackbar(it); vm.error = null } }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::sendMedia) }
    val doc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::sendMedia) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) camUri?.let(vm::sendMedia)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
            val f = File(dir, "cam_${System.currentTimeMillis()}.jpg")
            camUri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
            camera.launch(camUri!!)
        } else vm.error = "Permissão da câmara negada."
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) { vm.error = "Permissão de localização negada."; return@rememberLauncherForActivityResult }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        @Suppress("MissingPermission")
        val loc = runCatching {
            lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        }.getOrNull()
        if (loc != null) vm.sendLocation(loc.latitude, loc.longitude) else vm.error = "Localização indisponível."
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(contact?.name ?: "?", 36)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(contact?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                when (conn) {
                                    ConnState.CONNECTED -> "online (ligação direta)"
                                    ConnState.REQUESTING -> "a verificar se está online…"
                                    ConnState.CONNECTING -> "a ligar…"
                                    ConnState.DISCONNECTED -> "offline"
                                },
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { ttlMenu = true }) {
                            Icon(Icons.Filled.Timer, "Mensagens temporárias",
                                tint = if (vm.ttl > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        }
                        DropdownMenu(ttlMenu, { ttlMenu = false }) {
                            Constants.TTL_OPTIONS.forEach { (label, s) ->
                                DropdownMenuItem(text = { Text(label + if (vm.ttl == s) "  ✓" else "") },
                                    onClick = { vm.ttl = s; ttlMenu = false })
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Mais") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("Voltar a ligar") }, onClick = { menu = false; vm.reconnect() })
                            DropdownMenuItem(text = { Text("Limpar conversa") }, onClick = { menu = false; vm.clearChat() })
                            DropdownMenuItem(text = { Text("Bloquear contacto") }, onClick = { menu = false; vm.block(); onBack() })
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.surface).navigationBarsPadding().imePadding()) {
                vm.replyTo?.let { r ->
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("↩ " + preview(r), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { vm.replyTo = null }) { Icon(Icons.Filled.Close, "Cancelar") }
                    }
                }
                if (showEmoji) {
                    FlowRowEmojis { input += it }
                }
                Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.Bottom) {
                    IconButton(onClick = { showEmoji = !showEmoji }) { Icon(Icons.Filled.EmojiEmotions, "Emojis") }
                    var attach by remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { attach = true }) { Icon(Icons.Filled.AttachFile, "Anexar") }
                        DropdownMenu(attach, { attach = false }) {
                            DropdownMenuItem(text = { Text("Câmara") }, leadingIcon = { Icon(Icons.Filled.CameraAlt, null) },
                                onClick = { attach = false; camPerm.launch(Manifest.permission.CAMERA) })
                            DropdownMenuItem(text = { Text("Galeria") }, leadingIcon = { Icon(Icons.Filled.Image, null) },
                                onClick = { attach = false; gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) })
                            DropdownMenuItem(text = { Text("Documento") }, leadingIcon = { Icon(Icons.Filled.InsertDriveFile, null) },
                                onClick = { attach = false; doc.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("Localização") }, leadingIcon = { Icon(Icons.Filled.LocationOn, null) },
                                onClick = { attach = false; locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION) })
                        }
                    }
                    OutlinedTextField(
                        input, { input = it }, Modifier.weight(1f), maxLines = 5,
                        placeholder = { Text("Mensagem (*negrito* _itálico_ `código`)") },
                        shape = RoundedCornerShape(24.dp)
                    )
                    IconButton(
                        onClick = { vm.send(input); input = "" },
                        enabled = input.isNotBlank()
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Enviar", tint = MaterialTheme.colorScheme.primary) }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().background(LocalChatColors.current.background).padding(pad)) {
            LazyColumn(state = listState, contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(messages.size, key = { messages[it].id }) { i ->
                    val m = messages[i]
                    MessageBubble(
                        m, messages.firstOrNull { it.id == m.replyToId }, progress[m.id], now,
                        onReply = { vm.replyTo = m }, onReact = { vm.react(m, it) },
                        onOpen = { if (m.type == MsgType.VIDEO) video = m else openFile(ctx, m) },
                        onShare = { openFile(ctx, m, share = true) }
                    )
                }
            }
        }
    }
    video?.let { VideoDialog(it) { video = null } }
}

private fun preview(m: Message) = when (m.type) {
    MsgType.TEXT -> m.body
    MsgType.IMAGE -> "📷 Fotografia"
    MsgType.VIDEO -> "🎬 Vídeo"
    else -> "📎 ${m.mediaName}"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRowEmojis(onPick: (String) -> Unit) {
    FlowRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        Constants.EMOJIS.forEach { e ->
            Text(e, Modifier.clickable { onPick(e) }.padding(8.dp), style = MaterialTheme.typography.titleLarge)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    m: Message, quoted: Message?, progress: Float?, now: Long,
    onReply: () -> Unit, onReact: (String) -> Unit, onOpen: () -> Unit, onShare: () -> Unit
) {
    val colors = LocalChatColors.current
    var menu by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.outgoing) Arrangement.End else Arrangement.Start) {
        Box {
            Column(
                Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (m.outgoing) colors.sent else colors.received)
                    .combinedClickable(onClick = { if (m.type != MsgType.TEXT) onOpen() }, onLongClick = { menu = true })
                    .padding(8.dp)
            ) {
                quoted?.let {
                    Text(preview(it), Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).padding(6.dp),
                        maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                }
                when (m.type) {
                    MsgType.TEXT -> Text(formatRich(m.body), color = MaterialTheme.colorScheme.onSurface)
                    MsgType.IMAGE -> AsyncImage(File(m.mediaPath ?: ""), null, Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Fit)
                    MsgType.VIDEO -> Box(contentAlignment = Alignment.Center) {
                        AsyncImage(File(m.mediaPath ?: ""), null, Modifier.fillMaxWidth().heightIn(max = 220.dp), contentScale = ContentScale.Crop)
                        Icon(Icons.Filled.PlayCircle, "Reproduzir", Modifier.size(48.dp), tint = androidx.compose.ui.graphics.Color.White)
                    }
                    else -> Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.InsertDriveFile, null); Spacer(Modifier.width(8.dp))
                        Column {
                            Text(m.mediaName ?: "ficheiro", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${m.mediaSize / 1024} KB", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (progress != null) LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().padding(top = 4.dp))
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    m.expiresAt?.let {
                        Text("⏳ ${(it - now).toCountdown()}  ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    } ?: if (m.ttlSeconds > 0) Text("⏳  ", style = MaterialTheme.typography.labelSmall) else Unit
                    Text(m.createdAt.toClock(), style = MaterialTheme.typography.labelSmall)
                    if (m.outgoing) {
                        Spacer(Modifier.width(4.dp))
                        when (m.status) {
                            MsgStatus.PENDING -> Icon(Icons.Filled.Schedule, "Por enviar", Modifier.size(14.dp))
                            MsgStatus.SENT -> Icon(Icons.Filled.Done, "Enviada", Modifier.size(14.dp))
                            MsgStatus.RECEIVED -> Icon(Icons.Filled.DoneAll, "Recebida", Modifier.size(14.dp))
                            else -> Icon(Icons.Filled.DoneAll, "Vista", Modifier.size(14.dp), tint = SeenBlue)
                        }
                    }
                }
                m.reaction?.let { Text(it, Modifier.align(Alignment.End)) }
            }
            DropdownMenu(menu, { menu = false }) {
                Row(Modifier.padding(horizontal = 8.dp)) {
                    listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { e ->
                        Text(e, Modifier.clickable { menu = false; onReact(e) }.padding(6.dp), style = MaterialTheme.typography.titleLarge)
                    }
                }
                DropdownMenuItem(text = { Text("Responder") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Reply, null) }, onClick = { menu = false; onReply() })
                if (m.type == MsgType.TEXT)
                    DropdownMenuItem(text = { Text("Copiar") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) },
                        onClick = { menu = false; clipboard.setText(AnnotatedString(m.body)) })
                else DropdownMenuItem(text = { Text("Partilhar") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = { menu = false; onShare() })
            }
        }
    }
}

/** Reprodutor de vídeo (ExoPlayer) num diálogo. */
@Composable
private fun VideoDialog(m: Message, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(File(m.mediaPath ?: "")))); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Dialog(onDismissRequest = onClose) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player } }, Modifier.fillMaxWidth().height(300.dp))
    }
}
