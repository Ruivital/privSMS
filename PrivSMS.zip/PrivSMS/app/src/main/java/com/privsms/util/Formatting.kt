package com.privsms.util

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

/** Converte *negrito*, _itálico_ e `monospace` em texto formatado. */
fun formatRich(text: String): AnnotatedString = buildAnnotatedString {
    val regex = Regex("\\*([^*\\n]+)\\*|_([^_\\n]+)_|`([^`\\n]+)`")
    var last = 0
    for (m in regex.findAll(text)) {
        append(text.substring(last, m.range.first))
        val (b, i, c) = m.destructured
        when {
            b.isNotEmpty() -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(b) }
            i.isNotEmpty() -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(i) }
            else -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) { append(c) }
        }
        last = m.range.last + 1
    }
    append(text.substring(last))
}
