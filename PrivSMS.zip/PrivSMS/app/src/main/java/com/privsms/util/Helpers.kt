package com.privsms.util

import java.io.File
import java.io.RandomAccessFile

/** Apaga um ficheiro de forma segura: overwrite com zeros, sync e só depois delete. */
fun secureDelete(file: File) {
    if (!file.exists()) return
    runCatching {
        RandomAccessFile(file, "rw").use { raf ->
            val buf = ByteArray(8192)
            var left = raf.length()
            raf.seek(0)
            while (left > 0) {
                val n = minOf(left, buf.size.toLong()).toInt()
                raf.write(buf, 0, n)
                left -= n
            }
            raf.fd.sync()
        }
    }
    file.delete()
}

/** Mantém a pasta abaixo de [maxBytes], apagando primeiro os ficheiros mais antigos. */
fun trimDirectory(dir: File, maxBytes: Long) {
    val files = dir.listFiles()?.filter { it.isFile }?.sortedBy { it.lastModified() } ?: return
    var total = files.sumOf { it.length() }
    for (f in files) {
        if (total <= maxBytes) break
        total -= f.length()
        secureDelete(f)
    }
}
