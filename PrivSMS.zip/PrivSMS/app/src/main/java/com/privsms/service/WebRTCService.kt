package com.privsms.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.privsms.PrivSmsApp

/**
 * Serviço em primeiro plano que mantém a escuta de pedidos de ligação P2P.
 * Sem ele o Android suspenderia a app e o contacto pareceria "offline".
 */
class WebRTCService : Service() {
    override fun onCreate() {
        super.onCreate()
        val c = (application as PrivSmsApp).container
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, 1, c.notifier.serviceNotification(), type)
        c.startNetworking()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, WebRTCService::class.java))
    }
}
