package com.privsms.data.remote

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import com.privsms.util.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Descoberta e ligação de dispositivos próximos via Wi-Fi Direct.
 * Depois de formado o grupo, a sinalização corre por socket TCP local ([TcpSignaling]).
 * Requer dispositivo real (o emulador não suporta Wi-Fi Direct).
 */
@SuppressLint("MissingPermission")
class WifiDirectManager(private val context: Context, private val tcp: TcpSignaling) {

    private val manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private val channel = manager?.initialize(context, context.mainLooper, null)

    private val _peers = MutableStateFlow<List<WifiP2pDevice>>(emptyList())
    val peers = _peers.asStateFlow()
    private val _status = MutableStateFlow("")
    val status = _status.asStateFlow()

    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION ->
                    manager?.requestPeers(channel) { _peers.value = it.deviceList.toList() }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ->
                    manager?.requestConnectionInfo(channel) { info -> onConnectionInfo(info) }
            }
        }
    }

    private fun onConnectionInfo(info: WifiP2pInfo) {
        if (!info.groupFormed) return
        if (info.isGroupOwner) {
            _status.value = "Grupo criado. A aguardar o outro dispositivo…"
            tcp.listen(Constants.WIFI_DIRECT_PORT)
        } else {
            _status.value = "Ligado por Wi-Fi Direct."
            tcp.connect(info.groupOwnerAddress.hostAddress ?: return, Constants.WIFI_DIRECT_PORT)
        }
    }

    fun start() {
        if (manager == null) { _status.value = "Wi-Fi Direct não suportado neste dispositivo."; return }
        if (!registered) {
            val f = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            }
            context.registerReceiver(receiver, f)
            registered = true
        }
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { _status.value = "A procurar dispositivos próximos…" }
            override fun onFailure(reason: Int) { _status.value = "Falha na descoberta (código $reason). Ative o Wi-Fi e a localização." }
        })
    }

    fun connect(device: WifiP2pDevice) {
        val cfg = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager?.connect(channel, cfg, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { _status.value = "A ligar a ${device.deviceName}…" }
            override fun onFailure(reason: Int) { _status.value = "Não foi possível ligar (código $reason)." }
        })
    }

    fun stop() {
        if (registered) { runCatching { context.unregisterReceiver(receiver) }; registered = false }
        manager?.stopPeerDiscovery(channel, null)
        manager?.removeGroup(channel, null)
        tcp.stop()
    }
}
