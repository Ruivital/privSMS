package com.privsms.util

/** Constantes globais da aplicação. */
object Constants {
    /** Servidores STUN públicos (apenas descobrem o IP público; não veem mensagens). */
    val STUN_SERVERS = listOf(
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun.cloudflare.com:3478"
    )

    /** Relay público usado APENAS para sinalização cifrada (pedido de ligação, SDP, ICE). */
    const val DEFAULT_SIGNALING_URL = "https://ntfy.sh"

    const val WIFI_DIRECT_PORT = 8988
    const val CHUNK_SIZE = 16 * 1024
    const val MAX_FILE_BYTES = 50L * 1024 * 1024
    const val MAX_CACHE_BYTES = 100L * 1024 * 1024
    const val PING_TIMEOUT_MS = 20_000L
    const val SIGNAL_MAX_AGE_MS = 90_000L

    val TTL_OPTIONS: List<Pair<String, Long>> = listOf(
        "Desligado" to 0L, "1 min" to 60L, "5 min" to 300L, "1 h" to 3600L, "24 h" to 86400L
    )

    val EMOJIS = listOf(
        "😀","😂","😍","😎","🤔","😢","😡","👍","👎","🙏","👏","🔥","❤️","🎉","😮","😴",
        "🙌","💯","✅","❌","👀","🤝","😅","🥳","😇","🤯","💪","🍀","☕","🎶","📎","📍"
    )
}
