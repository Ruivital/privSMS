package com.privsms.data.repository

import android.net.Uri
import com.privsms.data.local.ContactEntity
import com.privsms.data.local.AppDatabase
import com.privsms.domain.model.Contact
import com.privsms.util.fromB64
import com.privsms.util.toB64
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Gestão de contactos e troca de chaves públicas via QR Code. */
class ContactRepository(private val db: AppDatabase, private val myPublicKey: ByteArray) {
    private val dao = db.contactDao()

    fun observeAll(): Flow<List<Contact>> = dao.observeAll().map { l -> l.map { Contact(it.publicKey, it.name, it.blocked) } }
    fun observe(key: String): Flow<Contact?> = dao.observe(key).map { e -> e?.let { Contact(it.publicKey, it.name, it.blocked) } }

    /** Conteúdo do QR com a minha identidade. */
    fun myInvite(name: String): String =
        "privsms://add?k=${myPublicKey.toB64()}&n=${Uri.encode(name)}"

    /** Adiciona um contacto a partir do texto de um QR. Devolve o contacto ou lança erro legível. */
    suspend fun addFromInvite(text: String): Contact {
        val uri = Uri.parse(text.trim())
        if (uri.scheme != "privsms" || uri.host != "add") throw IllegalArgumentException("QR Code inválido para o PrivSMS.")
        val key = uri.getQueryParameter("k") ?: throw IllegalArgumentException("QR Code sem chave.")
        val name = uri.getQueryParameter("n")?.takeIf { it.isNotBlank() } ?: "Contacto"
        val ok = runCatching { key.fromB64().size == 32 }.getOrDefault(false)
        if (!ok) throw IllegalArgumentException("Chave pública inválida.")
        if (key == myPublicKey.toB64()) throw IllegalArgumentException("Esse QR Code é o seu.")
        dao.upsert(ContactEntity(key, name.take(40)))
        return Contact(key, name)
    }

    suspend fun get(key: String) = dao.get(key)
    suspend fun rename(key: String, name: String) { dao.get(key)?.let { dao.upsert(it.copy(name = name.take(40))) } }
    suspend fun setBlocked(key: String, blocked: Boolean) = dao.setBlocked(key, blocked)
    suspend fun delete(key: String) = dao.delete(key)
}
