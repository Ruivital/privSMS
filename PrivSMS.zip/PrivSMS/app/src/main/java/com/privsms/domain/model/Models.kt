package com.privsms.domain.model

/** Estado de entrega de uma mensagem enviada. */
object MsgStatus {
    const val PENDING = 0   // por enviar (destinatário offline)
    const val SENT = 1      // escrita no canal, a aguardar confirmação
    const val RECEIVED = 2  // confirmada pelo destinatário
    const val SEEN = 3      // vista pelo destinatário
}

/** Tipo de conteúdo. */
object MsgType {
    const val TEXT = 0
    const val IMAGE = 1
    const val VIDEO = 2
    const val FILE = 3
}

/** Estado da ligação P2P com um contacto. */
enum class ConnState { DISCONNECTED, REQUESTING, CONNECTING, CONNECTED }

/** Contacto. [publicKey] (Base64 URL) é também o identificador. */
data class Contact(val publicKey: String, val name: String, val blocked: Boolean = false)

/** Mensagem de chat. */
data class Message(
    val id: String,
    val contactKey: String,
    val outgoing: Boolean,
    val type: Int,
    val body: String,
    val mediaPath: String?,
    val mediaName: String?,
    val mediaSize: Long,
    val replyToId: String?,
    val reaction: String?,
    val status: Int,
    val createdAt: Long,
    val ttlSeconds: Long,
    val viewedAt: Long?,
    val expiresAt: Long?
)

/** Linha da lista de conversas. */
data class Conversation(
    val contactKey: String,
    val name: String,
    val lastBody: String?,
    val lastType: Int?,
    val lastTime: Long?,
    val unread: Int
)

/** Regras de expiração das mensagens temporárias. */
object Expiry {
    /** Instante de destruição: visualização + TTL, ou null se não for temporária. */
    fun compute(viewedAt: Long, ttlSeconds: Long): Long? =
        if (ttlSeconds > 0) viewedAt + ttlSeconds * 1000 else null
}
