package com.privsms.ui.chats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.privsms.AppContainer
import com.privsms.domain.model.Conversation
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** Lista de conversas (ecrã principal). */
class ChatsViewModel(c: AppContainer) : ViewModel() {
    val conversations: StateFlow<List<Conversation>> =
        c.messages.conversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
