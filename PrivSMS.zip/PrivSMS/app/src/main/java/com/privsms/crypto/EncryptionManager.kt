package com.privsms.crypto

import com.privsms.util.toB64
import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cifra/decifra dados entre dois contactos.
 *
 * Esquema: X25519 (ECDH) -> HKDF-SHA256 -> chave AES-256 -> AES-GCM (IV aleatório de 12 bytes).
 * Formato do resultado: IV(12) || ciphertext || tag(16).
 *
 * Limitação conhecida: usa chaves estáticas (sem forward secrecy / double ratchet).
 */
class EncryptionManager(private val keys: KeyProvider) {

    private val random = SecureRandom()
    private val sessionKeys = ConcurrentHashMap<String, ByteArray>()

    /** Deriva (e guarda em cache) a chave de sessão partilhada com [peerPublic]. */
    fun sessionKey(peerPublic: ByteArray): ByteArray = sessionKeys.getOrPut(peerPublic.toB64()) {
        val agreement = X25519Agreement()
        agreement.init(X25519PrivateKeyParameters(keys.privateKey, 0))
        val secret = ByteArray(agreement.agreementSize)
        agreement.calculateAgreement(X25519PublicKeyParameters(peerPublic, 0), secret, 0)

        // Salt independente da ordem: concatena as duas chaves públicas ordenadas.
        val a = keys.publicKey
        val b = peerPublic
        val (first, second) = if (compare(a, b) <= 0) a to b else b to a
        hkdf(secret, first + second, "PrivSMS-v1".toByteArray())
    }

    /** Cifra [plain] para [peerPublic]. [aad] é autenticado mas não cifrado. */
    fun encrypt(peerPublic: ByteArray, plain: ByteArray, aad: ByteArray = ByteArray(0)): ByteArray {
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(sessionKey(peerPublic), "AES"), GCMParameterSpec(128, iv))
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        return iv + cipher.doFinal(plain)
    }

    /** Decifra; lança [java.security.GeneralSecurityException] se a autenticação falhar. */
    fun decrypt(peerPublic: ByteArray, data: ByteArray, aad: ByteArray = ByteArray(0)): ByteArray {
        require(data.size > IV_LEN + 16) { "Dados cifrados demasiado curtos" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE, SecretKeySpec(sessionKey(peerPublic), "AES"),
            GCMParameterSpec(128, data, 0, IV_LEN)
        )
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        return cipher.doFinal(data, IV_LEN, data.size - IV_LEN)
    }

    private fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)
        mac.init(SecretKeySpec(prk, "HmacSHA256"))
        mac.update(info)
        mac.update(0x01)
        return mac.doFinal() // 32 bytes = AES-256
    }

    private fun compare(a: ByteArray, b: ByteArray): Int {
        for (i in a.indices) {
            val d = (a[i].toInt() and 0xff) - (b[i].toInt() and 0xff)
            if (d != 0) return d
        }
        return 0
    }

    private companion object { const val IV_LEN = 12 }
}
