package com.privsms.util

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale

/** Codifica bytes em Base64 URL-safe sem padding (usado para chaves públicas e IDs). */
fun ByteArray.toB64(): String = Base64.getUrlEncoder().withoutPadding().encodeToString(this)

/** Descodifica Base64 URL-safe. */
fun String.fromB64(): ByteArray = Base64.getUrlDecoder().decode(this)

/** Codifica em Base64 normal (payloads cifrados). */
fun ByteArray.toB64Std(): String = Base64.getEncoder().encodeToString(this)

/** Descodifica Base64 normal. */
fun String.fromB64Std(): ByteArray = Base64.getDecoder().decode(this)

fun ByteArray.sha256(): ByteArray = MessageDigest.getInstance("SHA-256").digest(this)

fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

/** Impressão digital curta (para o utilizador comparar chaves). */
fun String.fingerprint(): String =
    fromB64().sha256().toHex().take(32).chunked(4).joinToString(" ")

/** Formata hora (HH:mm). */
fun Long.toClock(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(this))

/** Formata milissegundos restantes como m:ss ou h:mm:ss. */
fun Long.toCountdown(): String {
    val s = (this / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}
