package com.privsms.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import com.privsms.data.local.AppDatabase
import com.privsms.data.local.ConversationRow
import com.privsms.data.local.MessageEntity
import com.privsms.data.remote.WebRTCManager
import com.privsms.domain.model.ConnState
import com.privsms.domain.model.Conversation
import com.privsms.domain.model.Message
import com.privsms.domain.model.MsgStatus
import com.privsms.domain.model.MsgType
import com.privsms.service.ExpiryScheduler
import com.privsms.service.Notifier
import com.privsms.util.Constants
import com.privsms.util.secureDelete
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Repositório de mensagens: persistência, fila de envio, confirmações e temporizadores.
 *
 * Regras de entrega:
 *  - toda a mensagem é gravada primeiro como PENDING;
 *  - só é enviada com o destinatário online (PING/PONG + DataChannel aberto);
 *  - fica SENT até chegar o ACK (RECEIVED); sem ACK volta a ser reenviada na próxima ligação;
 *  - o recetor deduplica por ID, por isso reenvios são inofensivos.
 */
class MessageRepository(
    private val ctx: Context,
    db: AppDatabase,
    private val p2p: WebRTCManager,
    private val scope: CoroutineScope,
    private val notifier: Notifier,
    private val settings: SettingsStore
) {
    private val md = db.messageDao()
    private val cd = db.contactDao()
    private val mediaDir = File(ctx.filesDir, "media").apply { mkdirs() }

    /** Contacto cuja conversa está aberta (não notifica). */
    val activeChat = MutableStateFlow<String?>(null)
    /** Progresso (0..1) de transferências de ficheiros por ID de mensagem. */
    val progress = MutableStateFlow<Map<String, Float>>(emptyMap())

    private class Incoming(val meta: JSONObject, val file: File, val out: FileOutputStream, var received: Long = 0)
    private val incoming = ConcurrentHashMap<String, Incoming>()
    private val flushLocks = ConcurrentHashMap<String, Mutex>()
    private val lastState = ConcurrentHashMap<String, ConnState>()
    private val nextTry = ConcurrentHashMap<String, Long>()
    private val retryDelay = ConcurrentHashMap<String, Long>()

    // ------------------------------------------------------------------ consulta

    fun observe(contactKey: String): Flow<List<Message>> = md.observe(contactKey).map { l -> l.map { it.toModel() } }
    fun conversations(): Flow<List<Conversation>> = md.conversations().map { l -> l.map { it.toModel() } }

    // ------------------------------------------------------------------ arranque

    fun start() {
        scope.launch { p2p.frames.collect { (peer, plain) -> runCatching { onFrame(peer, plain) } } }
        scope.launch {
            p2p.states.collect { map ->
                map.forEach { (peer, st) ->
                    val prev = lastState.put(peer, st)
                    if (st == ConnState.CONNECTED && prev != ConnState.CONNECTED) {
                        retryDelay.remove(peer); nextTry.remove(peer)
                        launch { flush(peer); sendSeenBacklog(peer) }
                    }
                }
            }
        }
        // Reconexão automática com backoff para contactos com mensagens por entregar.
        scope.launch {
            while (true) {
                delay(5_000)
                runCatching {
                    for (peer in md.contactsWithUndelivered()) {
                        if (cd.get(peer)?.blocked != false) continue
                        if (p2p.stateOf(peer) != ConnState.DISCONNECTED) continue
                        if (System.currentTimeMillis() < (nextTry[peer] ?: 0)) continue
                        launch {
                            val ok = p2p.requestConnection(peer)
                            val d = if (ok) 0L else ((retryDelay[peer] ?: 5_000L) * 2).coerceAtMost(120_000L)
                            retryDelay[peer] = d
                            nextTry[peer] = System.currentTimeMillis() + d
                        }
                    }
                }
            }
        }
        scope.launch { purgeExpired() }
    }

    /** Tenta garantir ligação (ex.: ao abrir o chat). */
    fun ensureConnected(peer: String) {
        if (p2p.stateOf(peer) == ConnState.DISCONNECTED) scope.launch { p2p.requestConnection(peer) }
    }

    // ------------------------------------------------------------------ envio

    suspend fun sendText(contactKey: String, text: String, ttl: Long, replyTo: String?) {
        md.insert(
            MessageEntity(
                id = UUID.randomUUID().toString(), contactKey = contactKey, outgoing = true, type = MsgType.TEXT,
                body = text, replyToId = replyTo, status = MsgStatus.PENDING,
                createdAt = System.currentTimeMillis(), ttlSeconds = ttl
            )
        )
        kick(contactKey)
    }

    suspend fun sendMedia(contactKey: String, uri: Uri, ttl: Long, replyTo: String?) {
        val resolver = ctx.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val name = resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "ficheiro"
        val id = UUID.randomUUID().toString()
        val type = when {
            mime.startsWith("image/") -> MsgType.IMAGE
            mime.startsWith("video/") -> MsgType.VIDEO
            else -> MsgType.FILE
        }
        val target = File(mediaDir, id)
        if (type == MsgType.IMAGE) compressImage(uri, target)
        else resolver.openInputStream(uri)?.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            ?: throw IllegalArgumentException("Não foi possível ler o ficheiro.")
        if (target.length() > Constants.MAX_FILE_BYTES) {
            secureDelete(target)
            throw IllegalArgumentException("Ficheiro demasiado grande (máximo 50 MB).")
        }
        md.insert(
            MessageEntity(
                id = id, contactKey = contactKey, outgoing = true, type = type, body = "",
                mediaPath = target.absolutePath, mediaName = if (type == MsgType.IMAGE) "$name.jpg" else name,
                mediaSize = target.length(), replyToId = replyTo, status = MsgStatus.PENDING,
                createdAt = System.currentTimeMillis(), ttlSeconds = ttl
            )
        )
        kick(contactKey)
    }

    /** Comprime a imagem (máx. 1600 px, JPEG 80%) respeitando a orientação EXIF. */
    private fun compressImage(uri: Uri, target: File) {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
        var bmp = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalArgumentException("Imagem inválida.")
        val rotation = runCatching {
            resolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }
        }.getOrNull() ?: 0f
        val scale = 1600f / maxOf(bmp.width, bmp.height)
        val m = Matrix().apply { if (scale < 1f) postScale(scale, scale); postRotate(rotation) }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        target.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        bmp.recycle()
    }

    private fun kick(peer: String) {
        scope.launch {
            if (p2p.isConnected(peer)) flush(peer) else p2p.requestConnection(peer)
        }
    }

    /** Envia (por ordem) tudo o que ainda não foi confirmado. */
    private suspend fun flush(peer: String) {
        flushLocks.getOrPut(peer) { Mutex() }.withLock {
            for (m in md.undelivered(peer)) {
                if (!p2p.isConnected(peer)) return
                if (sendOne(peer, m)) md.raiseStatus(m.id, MsgStatus.SENT) else return
            }
        }
    }

    private suspend fun sendOne(peer: String, m: MessageEntity): Boolean {
        val j = JSONObject().put("t", "msg").put("id", m.id).put("type", m.type).put("body", m.body)
            .put("reply", m.replyToId ?: "").put("ttl", m.ttlSeconds).put("ts", m.createdAt)
            .put("name", m.mediaName ?: "").put("size", m.mediaSize)
        if (!p2p.send(peer, control(j))) return false
        if (m.type != MsgType.TEXT) {
            val f = File(m.mediaPath ?: return false)
            if (!f.exists()) return false
            val idBytes = m.id.toByteArray(Charsets.US_ASCII) // 36 bytes
            var sent = 0L
            f.inputStream().use { input ->
                val buf = ByteArray(Constants.CHUNK_SIZE)
                while (true) {
                    val n = input.read(buf); if (n <= 0) break
                    if (!p2p.send(peer, byteArrayOf(1) + idBytes + buf.copyOf(n))) return false
                    sent += n
                    progress.update { it + (m.id to sent.toFloat() / m.mediaSize) }
                }
            }
            progress.update { it - m.id }
        }
        return true
    }

    private fun control(j: JSONObject) = byteArrayOf(0) + j.toString().toByteArray()

    // ------------------------------------------------------------------ receção

    private suspend fun onFrame(peer: String, plain: ByteArray) {
        if (plain.isEmpty()) return
        if (plain[0].toInt() == 1) { onChunk(peer, plain); return }
        val j = JSONObject(String(plain, 1, plain.size - 1))
        when (j.getString("t")) {
            "msg" -> onMsg(peer, j)
            "ack" -> md.raiseStatus(j.getString("id"), MsgStatus.RECEIVED)
            "seen" -> {
                val ids = j.getJSONArray("ids")
                val now = System.currentTimeMillis()
                for (i in 0 until ids.length()) {
                    val id = ids.getString(i)
                    md.raiseStatus(id, MsgStatus.SEEN); md.markViewed(id, now)
                }
                scheduleNextExpiry()
            }
            "react" -> md.setReaction(j.getString("id"), j.optString("e").ifEmpty { null })
        }
    }

    private suspend fun onMsg(peer: String, j: JSONObject) {
        val c = cd.get(peer) ?: return
        if (c.blocked) return
        val id = j.getString("id")
        if (md.get(id) != null) { p2p.send(peer, ack(id)); return } // duplicado: só re-confirma
        val type = j.getInt("type")
        if (type == MsgType.TEXT) {
            val inserted = md.insert(
                MessageEntity(
                    id = id, contactKey = peer, outgoing = false, type = type, body = j.getString("body"),
                    replyToId = j.optString("reply").ifEmpty { null }, status = MsgStatus.RECEIVED,
                    createdAt = System.currentTimeMillis(), ttlSeconds = j.optLong("ttl")
                )
            )
            p2p.send(peer, ack(id))
            if (inserted != -1L) notify(peer, c.name, j.getString("body"))
        } else {
            val size = j.getLong("size")
            if (size > Constants.MAX_FILE_BYTES) return
            incoming.remove(id)?.out?.close()
            val f = File(mediaDir, id)
            incoming[id] = Incoming(j, f, FileOutputStream(f, false))
            if (size == 0L) finishIncoming(peer, id)
        }
    }

    private suspend fun onChunk(peer: String, plain: ByteArray) {
        val id = String(plain, 1, 36, Charsets.US_ASCII)
        val inc = incoming[id] ?: return
        inc.out.write(plain, 37, plain.size - 37)
        inc.received += plain.size - 37
        val size = inc.meta.getLong("size")
        progress.update { it + (id to inc.received.toFloat() / size) }
        if (inc.received >= size) finishIncoming(peer, id)
    }

    private suspend fun finishIncoming(peer: String, id: String) {
        val inc = incoming.remove(id) ?: return
        inc.out.close()
        progress.update { it - id }
        val c = cd.get(peer) ?: return
        val j = inc.meta
        md.insert(
            MessageEntity(
                id = id, contactKey = peer, outgoing = false, type = j.getInt("type"), body = "",
                mediaPath = inc.file.absolutePath, mediaName = j.optString("name"), mediaSize = j.getLong("size"),
                replyToId = j.optString("reply").ifEmpty { null }, status = MsgStatus.RECEIVED,
                createdAt = System.currentTimeMillis(), ttlSeconds = j.optLong("ttl")
            )
        )
        p2p.send(peer, ack(id)) // ACK só depois do ficheiro estar completo
        notify(peer, c.name, "📎 ${j.optString("name")}")
    }

    private fun ack(id: String) = control(JSONObject().put("t", "ack").put("id", id))

    private fun notify(peer: String, name: String, text: String) {
        if (activeChat.value == peer) return
        notifier.message(peer, name, text, settings.hidePreview.value)
    }

    // ------------------------------------------------------------------ vistas / reações / limpeza

    /** Marca como vistas as mensagens recebidas, inicia os timers e avisa o remetente. */
    suspend fun markSeen(peer: String) {
        val unseen = md.unseenIncoming(peer)
        if (unseen.isEmpty()) return
        val now = System.currentTimeMillis()
        unseen.forEach { md.markViewed(it.id, now) }
        scheduleNextExpiry()
        val ids = JSONArray(unseen.map { it.id })
        p2p.send(peer, control(JSONObject().put("t", "seen").put("ids", ids)))
    }

    private suspend fun sendSeenBacklog(peer: String) {
        val ids = md.viewedIncomingIds(peer)
        if (ids.isNotEmpty()) p2p.send(peer, control(JSONObject().put("t", "seen").put("ids", JSONArray(ids))))
    }

    suspend fun react(peer: String, id: String, emoji: String?) {
        md.setReaction(id, emoji)
        p2p.send(peer, control(JSONObject().put("t", "react").put("id", id).put("e", emoji ?: "")))
    }

    /** Apaga mensagens expiradas (ficheiros com overwrite de zeros + secure_delete na BD). */
    suspend fun purgeExpired(): Int {
        val list = md.expired(System.currentTimeMillis())
        list.forEach { m -> m.mediaPath?.let { secureDelete(File(it)) } }
        if (list.isNotEmpty()) md.delete(list.map { it.id })
        scheduleNextExpiry()
        return list.size
    }

    suspend fun clearChat(peer: String) {
        md.allFor(peer).forEach { m -> m.mediaPath?.let { secureDelete(File(it)) } }
        md.clear(peer)
    }

    private suspend fun scheduleNextExpiry() {
        md.nextExpiry()?.let { ExpiryScheduler.schedule(ctx, (it - System.currentTimeMillis()).coerceAtLeast(0)) }
    }

    // ------------------------------------------------------------------ mapeamento

    private fun MessageEntity.toModel() = Message(
        id, contactKey, outgoing, type, body, mediaPath, mediaName, mediaSize, replyToId,
        reaction, status, createdAt, ttlSeconds, viewedAt, expiresAt
    )

    private fun ConversationRow.toModel() = Conversation(contactKey, name, lastBody, lastType, lastTime, unread)
}
