package com.privsms.ui.chat

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.privsms.AppContainer
import com.privsms.domain.model.ConnState
import com.privsms.domain.model.Contact
import com.privsms.domain.model.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Estado e ações de uma conversa. */
class ChatViewModel(private val c: AppContainer, val key: String) : ViewModel() {

    val contact: StateFlow<Contact?> =
        c.contacts.observe(key).stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val messages: StateFlow<List<Message>> =
        c.messages.observe(key).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val connection: StateFlow<ConnState> =
        c.p2p.states.map { it[key] ?: ConnState.DISCONNECTED }
            .stateIn(viewModelScope, SharingStarted.Eagerly, ConnState.DISCONNECTED)
    val progress = c.messages.progress

    /** Temporizador das mensagens que vou enviar (segundos; 0 = desligado). */
    var ttl by mutableStateOf(c.settings.defaultTtl.value)
    var replyTo by mutableStateOf<Message?>(null)
    var error by mutableStateOf<String?>(null)

    init {
        c.messages.activeChat.value = key
        c.messages.ensureConnected(key)
        // Sempre que chegam mensagens com o chat aberto, marca como vistas.
        viewModelScope.launch {
            messages.collect { if (it.any { m -> !m.outgoing && m.viewedAt == null }) c.markSeen(key) }
        }
    }

    fun send(text: String) {
        val reply = replyTo?.id; replyTo = null
        viewModelScope.launch { runCatching { c.sendMessage(key, text, ttl, reply) }.onFailure { error = it.message } }
    }

    fun sendMedia(uri: Uri) {
        val reply = replyTo?.id; replyTo = null
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { c.sendMedia(key, uri, ttl, reply) }
                .onFailure { error = it.message ?: "Não foi possível enviar o ficheiro." }
        }
    }

    fun sendLocation(lat: Double, lon: Double) = send("📍 Localização: $lat, $lon\ngeo:$lat,$lon")

    fun react(m: Message, emoji: String) {
        viewModelScope.launch { c.messages.react(key, m.id, if (m.reaction == emoji) null else emoji) }
    }

    fun clearChat() { viewModelScope.launch { c.messages.clearChat(key) } }
    fun block() { viewModelScope.launch { c.contacts.setBlocked(key, true) } }
    fun reconnect() = c.messages.ensureConnected(key)

    override fun onCleared() {
        if (c.messages.activeChat.value == key) c.messages.activeChat.value = null
    }
}
