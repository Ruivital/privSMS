package com.privsms.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val publicKey: String,
    val name: String,
    val blocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "messages",
    indices = [Index("contactKey"), Index("expiresAt")]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val contactKey: String,
    val outgoing: Boolean,
    val type: Int,
    val body: String,
    val mediaPath: String? = null,
    val mediaName: String? = null,
    val mediaSize: Long = 0,
    val replyToId: String? = null,
    val reaction: String? = null,
    val status: Int,
    val createdAt: Long,
    val ttlSeconds: Long = 0,
    val viewedAt: Long? = null,
    val expiresAt: Long? = null
)

/** Resultado da query de conversas. */
data class ConversationRow(
    val contactKey: String,
    val name: String,
    val lastBody: String?,
    val lastType: Int?,
    val lastTime: Long?,
    val unread: Int
)
