package com.privsms

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.privsms.service.WebRTCService
import com.privsms.ui.chat.ChatScreen
import com.privsms.ui.chat.ChatViewModel
import com.privsms.ui.chats.ChatsScreen
import com.privsms.ui.chats.ChatsViewModel
import com.privsms.ui.contacts.ContactsScreen
import com.privsms.ui.contacts.ContactsViewModel
import com.privsms.ui.settings.SettingsScreen
import com.privsms.ui.theme.PrivSmsTheme
import kotlinx.coroutines.launch

/** Atividade única (Compose + Navigation). FragmentActivity é exigido pelo BiometricPrompt. */
class MainActivity : FragmentActivity() {

    private val container get() = (application as PrivSmsApp).container
    private var locked by mutableStateOf(false)
    private var openChat by mutableStateOf<String?>(null)

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private fun factory(create: () -> ViewModel) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = create() as T
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FLAG_SECURE: impede capturas de ecrã e miniatura nos "recentes".
        lifecycleScope.launch {
            container.settings.secureScreen.collect { on ->
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
        locked = container.settings.lockEnabled.value
        openChat = intent.getStringExtra("open_chat")
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        container.startNetworking()
        WebRTCService.start(this)

        setContent {
            PrivSmsTheme {
                if (locked) LockScreen() else AppNav()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        openChat = intent.getStringExtra("open_chat")
    }

    override fun onStop() {
        super.onStop()
        if (container.settings.lockEnabled.value) locked = true
    }

    private fun authenticate() {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            locked = false // sem biometria/PIN configurados no telemóvel: não bloquear
            return
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("PrivSMS").setSubtitle("Autentique-se para abrir a app")
            .setAllowedAuthenticators(auth).build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { locked = false }
        }).authenticate(info)
    }

    @Composable
    private fun LockScreen() {
        LaunchedEffect(Unit) { authenticate() }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PrivSMS bloqueado")
                Spacer(Modifier.height(12.dp))
                Button(onClick = { authenticate() }) { Text("Desbloquear") }
            }
        }
    }

    @Composable
    private fun AppNav() {
        val nav = rememberNavController()
        LaunchedEffect(openChat) {
            openChat?.let { nav.navigate("chat/$it"); openChat = null }
        }
        NavHost(nav, startDestination = "chats") {
            composable("chats") {
                val vm: ChatsViewModel = viewModel(factory = factory { ChatsViewModel(container) })
                ChatsScreen(vm, onOpen = { nav.navigate("chat/$it") },
                    onContacts = { nav.navigate("contacts") }, onSettings = { nav.navigate("settings") })
            }
            composable("chat/{key}") { entry ->
                val key = entry.arguments?.getString("key").orEmpty()
                val vm: ChatViewModel = viewModel(factory = factory { ChatViewModel(container, key) })
                ChatScreen(vm, onBack = { nav.popBackStack() })
            }
            composable("contacts") {
                val vm: ContactsViewModel = viewModel(factory = factory { ContactsViewModel(container) })
                ContactsScreen(vm, onBack = { nav.popBackStack() }, onOpen = { nav.navigate("chat/$it") })
            }
            composable("settings") {
                SettingsScreen(container.settings, container.keys.publicKey) { nav.popBackStack() }
            }
        }
    }
}
