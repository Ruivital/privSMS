package com.privsms.data.remote

import com.privsms.domain.model.ConnState
import com.privsms.util.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Tipos de mensagens de sinalização. */
enum class SignalType { PING, PONG, OFFER, ANSWER, ICE }

private open class SdpObs : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

/**
 * Ligação WebRTC (DataChannel) com UM contacto.
 * A sinalização é entregue via [sendSignal] (já cifrada pelo [WebRTCManager]).
 */
class P2PConnection(
    private val factory: PeerConnectionFactory,
    private val scope: CoroutineScope,
    private val sendSignal: suspend (SignalType, String) -> Unit,
    private val onFrame: (ByteArray) -> Unit,
    private val onStateChanged: (ConnState) -> Unit
) {
    @Volatile var state: ConnState = ConnState.DISCONNECTED
        private set
    val isInitiator get() = initiator

    private var pc: PeerConnection? = null
    private var dc: DataChannel? = null
    private var initiator = false
    private val pendingIce = mutableListOf<IceCandidate>()
    private var remoteSet = false

    private fun setState(s: ConnState) { state = s; onStateChanged(s) }

    private fun iceServers() = Constants.STUN_SERVERS.map {
        PeerConnection.IceServer.builder(it).createIceServer()
    }

    private fun createPc(): PeerConnection? {
        val cfg = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        return factory.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                when (s) {
                    PeerConnection.IceConnectionState.FAILED,
                    PeerConnection.IceConnectionState.CLOSED,
                    PeerConnection.IceConnectionState.DISCONNECTED -> close()
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate) {
                val j = JSONObject().put("mid", c.sdpMid).put("idx", c.sdpMLineIndex).put("sdp", c.sdp)
                scope.launch { runCatching { sendSignal(SignalType.ICE, j.toString()) } }
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(ch: DataChannel) { attachChannel(ch) }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
        })
    }

    private fun attachChannel(ch: DataChannel) {
        dc = ch
        ch.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(prev: Long) {}
            override fun onStateChange() {
                when (ch.state()) {
                    DataChannel.State.OPEN -> setState(ConnState.CONNECTED)
                    DataChannel.State.CLOSED, DataChannel.State.CLOSING -> close()
                    else -> {}
                }
            }
            override fun onMessage(b: DataChannel.Buffer) {
                val bytes = ByteArray(b.data.remaining()).also { b.data.get(it) }
                onFrame(bytes)
            }
        })
        if (ch.state() == DataChannel.State.OPEN) setState(ConnState.CONNECTED)
    }

    /** Inicia a ligação. [asInitiator] cria o DataChannel e a oferta SDP. */
    suspend fun start(asInitiator: Boolean) {
        close(silent = true)
        initiator = asInitiator
        setState(ConnState.CONNECTING)
        pc = createPc() ?: run { close(); return }
        if (asInitiator) {
            val init = DataChannel.Init().apply { ordered = true }
            attachChannel(pc!!.createDataChannel("privsms", init))
            val offer = createDesc { pc!!.createOffer(it, MediaConstraints()) }
            setLocal(offer)
            sendSignal(SignalType.OFFER, offer.description)
        }
    }

    /** Recebe sinalização do outro lado. */
    suspend fun onSignal(type: SignalType, data: String) {
        when (type) {
            SignalType.OFFER -> {
                start(false)
                val p = pc ?: return
                setRemote(SessionDescription(SessionDescription.Type.OFFER, data))
                val answer = createDesc { p.createAnswer(it, MediaConstraints()) }
                setLocal(answer)
                sendSignal(SignalType.ANSWER, answer.description)
            }
            SignalType.ANSWER -> setRemote(SessionDescription(SessionDescription.Type.ANSWER, data))
            SignalType.ICE -> {
                val j = JSONObject(data)
                val c = IceCandidate(j.getString("mid"), j.getInt("idx"), j.getString("sdp"))
                if (remoteSet) pc?.addIceCandidate(c) else pendingIce += c
            }
            else -> {}
        }
    }

    private suspend fun setRemote(d: SessionDescription) = suspendCancellableCoroutine<Unit> { cont ->
        val p = pc ?: return@suspendCancellableCoroutine cont.resumeWithException(IllegalStateException("sem pc"))
        p.setRemoteDescription(object : SdpObs() {
            override fun onSetSuccess() {
                remoteSet = true
                pendingIce.forEach { p.addIceCandidate(it) }; pendingIce.clear()
                cont.resume(Unit)
            }
            override fun onSetFailure(e: String?) { cont.resumeWithException(IllegalStateException(e)) }
        }, d)
    }

    private suspend fun setLocal(d: SessionDescription) = suspendCancellableCoroutine<Unit> { cont ->
        pc?.setLocalDescription(object : SdpObs() {
            override fun onSetSuccess() { cont.resume(Unit) }
            override fun onSetFailure(e: String?) { cont.resumeWithException(IllegalStateException(e)) }
        }, d)
    }

    private suspend fun createDesc(block: (SdpObserver) -> Unit) =
        suspendCancellableCoroutine<SessionDescription> { cont ->
            block(object : SdpObs() {
                override fun onCreateSuccess(d: SessionDescription?) { cont.resume(d!!) }
                override fun onCreateFailure(e: String?) { cont.resumeWithException(IllegalStateException(e)) }
            })
        }

    /** Envia um frame, respeitando o buffer do canal (backpressure). */
    suspend fun send(bytes: ByteArray): Boolean {
        val ch = dc ?: return false
        var waited = 0
        while (ch.bufferedAmount() > 1_000_000 && waited < 3000) { delay(10); waited++ }
        if (ch.state() != DataChannel.State.OPEN) return false
        return ch.send(DataChannel.Buffer(ByteBuffer.wrap(bytes), true))
    }

    fun close(silent: Boolean = false) {
        runCatching { dc?.close(); dc?.dispose() }
        runCatching { pc?.close(); pc?.dispose() }
        dc = null; pc = null; remoteSet = false; pendingIce.clear()
        if (!silent && state != ConnState.DISCONNECTED) setState(ConnState.DISCONNECTED)
        else if (silent) state = ConnState.DISCONNECTED
    }
}
