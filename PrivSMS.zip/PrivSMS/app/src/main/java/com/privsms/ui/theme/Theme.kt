package com.privsms.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Cores específicas do chat (bolhas e fundo). */
data class ChatColors(val sent: Color, val received: Color, val background: Color)

val LocalChatColors = staticCompositionLocalOf { ChatColors(BubbleSentLight, BubbleRecvLight, ChatBgLight) }

/** Tema Material 3 com modo claro/escuro automático (segue o sistema). */
@Composable
fun PrivSmsTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(primary = TealLight, secondary = TealLight, primaryContainer = Teal)
    else lightColorScheme(primary = Teal, secondary = TealLight)
    val chat = if (dark) ChatColors(BubbleSentDark, BubbleRecvDark, ChatBgDark)
    else ChatColors(BubbleSentLight, BubbleRecvLight, ChatBgLight)
    androidx.compose.runtime.CompositionLocalProvider(LocalChatColors provides chat) {
        MaterialTheme(colorScheme = scheme, typography = AppTypography, content = content)
    }
}
