package com.privsms

import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.privsms.crypto.EncryptionManager
import com.privsms.crypto.KeyManager
import com.privsms.data.local.AppDatabase
import com.privsms.data.remote.MultiSignaling
import com.privsms.data.remote.NtfySignaling
import com.privsms.data.remote.TcpSignaling
import com.privsms.data.remote.WebRTCManager
import com.privsms.data.remote.WifiDirectManager
import com.privsms.data.repository.ContactRepository
import com.privsms.data.repository.MessageRepository
import com.privsms.data.repository.SettingsStore
import com.privsms.domain.usecase.DeleteExpiredMessagesUseCase
import com.privsms.domain.usecase.MarkConversationSeenUseCase
import com.privsms.domain.usecase.SendMediaUseCase
import com.privsms.domain.usecase.SendMessageUseCase
import com.privsms.service.ExpiryScheduler
import com.privsms.service.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Application: cria o contentor de dependências e configura o Coil (miniaturas de vídeo). */
class PrivSmsApp : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        ExpiryScheduler.ensurePeriodic(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this).components { add(VideoFrameDecoder.Factory()) }.build()
}

/** Injeção de dependências manual (simples e sem geração de código). */
class AppContainer(ctx: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = SettingsStore(ctx)
    val keys = KeyManager(ctx)
    val crypto = EncryptionManager(keys)
    val db = AppDatabase.build(ctx, keys.databasePassphrase())
    val notifier = Notifier(ctx)

    private val tcp = TcpSignaling()
    private val signaling = MultiSignaling(NtfySignaling { settings.signalingUrl.value }, tcp)
    val wifiDirect = WifiDirectManager(ctx, tcp)

    val p2p = WebRTCManager(ctx, keys, crypto, signaling, scope) { key ->
        db.contactDao().get(key)?.blocked == false
    }
    val messages = MessageRepository(ctx, db, p2p, scope, notifier, settings)
    val contacts = ContactRepository(db, keys.publicKey)

    val sendMessage = SendMessageUseCase(messages)
    val sendMedia = SendMediaUseCase(messages)
    val markSeen = MarkConversationSeenUseCase(messages)
    private val deleteExpiredUc = DeleteExpiredMessagesUseCase(messages)
    suspend fun deleteExpired() = deleteExpiredUc()

    private var started = false

    /** Arranca a rede P2P (idempotente). */
    @Synchronized
    fun startNetworking() {
        if (started) return
        started = true
        messages.start()
        p2p.start()
    }
}
