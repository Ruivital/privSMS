package com.privsms.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.privsms.PrivSmsApp
import com.privsms.util.Constants
import com.privsms.util.trimDirectory
import java.io.File
import java.util.concurrent.TimeUnit

/** Agenda o apagar de mensagens temporárias via WorkManager (funciona com a app fechada). */
object ExpiryScheduler {
    fun schedule(ctx: Context, delayMs: Long) {
        val req = OneTimeWorkRequestBuilder<MessageTimerWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("privsms_expiry", ExistingWorkPolicy.REPLACE, req)
    }

    /** Rede de segurança: verificação periódica a cada 15 min. */
    fun ensurePeriodic(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<MessageTimerWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("privsms_expiry_periodic", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

/** Worker que apaga mensagens expiradas e limpa a cache. */
class MessageTimerWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as PrivSmsApp).container
        container.deleteExpired()
        trimDirectory(File(applicationContext.cacheDir, "shared"), Constants.MAX_CACHE_BYTES)
        return Result.success()
    }
}
