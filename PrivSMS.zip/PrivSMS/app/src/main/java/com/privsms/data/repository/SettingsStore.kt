package com.privsms.data.repository

import android.content.Context
import com.privsms.util.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Definições da app (não sensíveis). */
class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("privsms_settings", Context.MODE_PRIVATE)

    private fun <T> flowOf(initial: T) = MutableStateFlow(initial)

    private val _name = flowOf(p.getString("name", "Eu")!!)
    private val _lock = flowOf(p.getBoolean("lock", false))
    private val _hide = flowOf(p.getBoolean("hide_preview", true))
    private val _secure = flowOf(p.getBoolean("secure", true))
    private val _ttl = flowOf(p.getLong("ttl", 0L))
    private val _url = flowOf(p.getString("signaling", Constants.DEFAULT_SIGNALING_URL)!!)

    val name = _name.asStateFlow()
    val lockEnabled = _lock.asStateFlow()
    val hidePreview = _hide.asStateFlow()
    val secureScreen = _secure.asStateFlow()
    val defaultTtl = _ttl.asStateFlow()
    val signalingUrl = _url.asStateFlow()

    fun setName(v: String) { p.edit().putString("name", v).apply(); _name.value = v }
    fun setLock(v: Boolean) { p.edit().putBoolean("lock", v).apply(); _lock.value = v }
    fun setHidePreview(v: Boolean) { p.edit().putBoolean("hide_preview", v).apply(); _hide.value = v }
    fun setSecureScreen(v: Boolean) { p.edit().putBoolean("secure", v).apply(); _secure.value = v }
    fun setDefaultTtl(v: Long) { p.edit().putLong("ttl", v).apply(); _ttl.value = v }
    fun setSignalingUrl(v: String) { p.edit().putString("signaling", v.trim()).apply(); _url.value = v.trim() }
}
