package com.privsms.ui.theme

import androidx.compose.ui.graphics.Color

val Teal = Color(0xFF075E54)
val TealLight = Color(0xFF25D366)
val BubbleSentLight = Color(0xFFDCF8C6)
val BubbleSentDark = Color(0xFF005C4B)
val BubbleRecvLight = Color(0xFFFFFFFF)
val BubbleRecvDark = Color(0xFF202C33)
val ChatBgLight = Color(0xFFECE5DD)
val ChatBgDark = Color(0xFF0B141A)
val SeenBlue = Color(0xFF34B7F1)
